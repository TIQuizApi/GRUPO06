# Quiz app javascript

Com Operações GET / POST 

Jogo de perguntas e resposta sobre javascript. O quiz possui 5 perguntas referente a linguagem de programação javascript.
O jogo tambem possui um metodo post que permite o usuário adcionar perguntas atraves de um login e senha.


##Para usar esse projeto:

1. Clonar este repositório

```
https://github.com/TIQuizApi/GROUP02.git
```

2. entrar na pasta ou abrir o projeto (pasta) no VSCode

3. abrir terminal

4. dar o comando

```
    npm install
    npm run server
```

durante a aula utilizei as extensões:

Thunder Client
Liver Server

Adicionamos o módulo ```jsonwebtoken```

https://developer.mozilla.org/pt-BR/docs/Web/API/Fetch_API/Using_Fetch
https://axios-http.com/docs/intro

## Estrutura de pastas do projeto

pasta ```database``` contém o arquivo json que é o banco de dados e o arquivo ```sgdb.js``` que controla a persistência dos dados no arquivo json.

